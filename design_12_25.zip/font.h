#ifndef FRONT_H
#define FRONT_H

extern const unsigned char F6x8[][6];

extern const unsigned char F8X16[][16];


#endif
